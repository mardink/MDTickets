
CREATE TABLE IF NOT EXISTS `#__mdtickets_items` (
  `mdtickets_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mdtickets_category_id` bigint(20) NOT NULL,
  `fromname` varchar(255) NOT NULL,
  `fromemail` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `body` mediumtext NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT 1,
  `token` char(32) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` bigint(20) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` bigint(20) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mdtickets_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
